
import React from 'react';
import { Anchor, Waves, Wind } from 'lucide-react';

const MarineSection: React.FC = () => {
  return (
    <section id="nautica" className="py-24 bg-yellow-400 relative overflow-hidden">
      {/* Pattern background */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col items-center text-center mb-16">
          <div className="bg-black text-white p-3 mb-6 inline-block">
            <Anchor size={32} />
          </div>
          <h2 className="font-heading text-4xl md:text-6xl font-black text-black mb-6 uppercase tracking-tighter">
            DIVISIÓN NÁUTICA <br /> ESPECIALIZADA
          </h2>
          <p className="max-w-2xl text-black/80 text-xl font-medium leading-relaxed">
            Expertos en el mantenimiento y reparación de motores marinos. Prepará tu embarcación para disfrutar del agua con total seguridad.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-black p-10 group hover:-translate-y-2 transition-transform duration-500">
             <Waves className="text-yellow-400 mb-6" size={40} />
             <h4 className="text-white font-black text-xl mb-4 uppercase">Motores Fuera de Borda</h4>
             <p className="text-gray-400 text-sm">Service oficial, diagnóstico y reparación de todas las marcas líderes del mercado.</p>
          </div>
          <div className="bg-black p-10 group hover:-translate-y-2 transition-transform duration-500">
             <Wind className="text-yellow-400 mb-6" size={40} />
             <h4 className="text-white font-black text-xl mb-4 uppercase">Puesta a Punto Verano</h4>
             <p className="text-gray-400 text-sm">Alistamiento integral para que tu motor responda perfectamente en temporada alta.</p>
          </div>
          <div className="bg-black p-10 group hover:-translate-y-2 transition-transform duration-500">
             <Anchor className="text-yellow-400 mb-6" size={40} />
             <h4 className="text-white font-black text-xl mb-4 uppercase">Motores Internos</h4>
             <p className="text-gray-400 text-sm">Especialistas en diesel y gasolina para cruceros y lanchas de gran porte.</p>
          </div>
        </div>

        <div className="flex justify-center">
          <a href="#contacto" className="inline-block border-4 border-black text-black px-12 py-5 font-black text-xl uppercase tracking-tighter hover:bg-black hover:text-yellow-400 transition-all duration-300">
            Consultar Service Náutico
          </a>
        </div>
      </div>
    </section>
  );
};

export default MarineSection;
