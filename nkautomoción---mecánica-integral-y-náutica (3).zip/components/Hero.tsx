
import React from 'react';
import { ChevronRight, Settings } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background with Industrial Texture & Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/id/446/1920/1080" 
          alt="Workshop background" 
          className="w-full h-full object-cover grayscale opacity-30 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
        {/* Decorative Grid */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#FACC15_1px,transparent_1px)] [background-size:20px_20px]"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-yellow-400/10 border border-yellow-400/30 px-4 py-1.5 rounded-full mb-6">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
            </span>
            <span className="text-yellow-400 text-xs font-bold uppercase tracking-widest">Servicio Técnico Especializado</span>
          </div>

          <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl font-black text-white leading-tight mb-6">
            POTENCIA, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-600">CONFIANZA</span> <br />
            & PRECISIÓN.
          </h1>

          <p className="text-gray-400 text-lg md:text-xl max-w-xl mb-10 leading-relaxed border-l-4 border-yellow-400 pl-6">
            En <span className="text-white font-bold">NKAUTOMOCIÓN</span> llevamos la mecánica al siguiente nivel. 
            Soluciones integrales para vehículos particulares, flotas empresariales y motores náuticos.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a 
              href="#contacto" 
              className="group bg-yellow-400 text-black px-8 py-5 font-black text-lg uppercase tracking-tighter flex items-center justify-center gap-2 hover:bg-white transition-all duration-300 shadow-[8px_8px_0px_rgba(250,204,21,0.2)]"
            >
              Agendá tu servicio
              <ChevronRight className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#servicios" 
              className="border-2 border-white/20 text-white hover:border-yellow-400 hover:text-yellow-400 px-8 py-5 font-black text-lg uppercase tracking-tighter flex items-center justify-center gap-2 transition-all duration-300"
            >
              Nuestros Servicios
              <Settings className="animate-spin-slow" size={20} />
            </a>
          </div>
        </div>
      </div>

      {/* Side Decorative Text (Desktop) */}
      <div className="hidden lg:block absolute -right-32 bottom-20 rotate-90 opacity-10">
        <span className="text-9xl font-black tracking-tighter text-white select-none uppercase">MECHANICAL ENGINEERING</span>
      </div>
    </section>
  );
};

export default Hero;
