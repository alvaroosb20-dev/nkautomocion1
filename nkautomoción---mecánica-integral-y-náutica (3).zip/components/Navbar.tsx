
import React, { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Inicio', href: '#inicio' },
    { name: 'Servicios', href: '#servicios' },
    { name: 'Náutica', href: '#nautica' },
    { name: 'Empresas', href: '#empresas' },
    { name: 'Nosotros', href: '#nosotros' },
    { name: 'Contacto', href: '#contacto' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/95 border-b border-yellow-400/30 py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center gap-2">
            <div className="bg-yellow-400 p-1 rounded-sm rotate-3 shadow-[2px_2px_0px_#000]">
              <span className="text-black font-black text-xl italic leading-none">NK</span>
            </div>
            <span className="text-white font-heading font-black text-xl tracking-tighter">AUTOMOCIÓN</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-gray-300 hover:text-yellow-400 font-medium transition-colors text-sm uppercase tracking-wider"
              >
                {link.name}
              </a>
            ))}
            <a
              href="#presupuesto"
              className="bg-yellow-400 text-black px-6 py-2.5 rounded-none font-bold text-sm uppercase tracking-tighter hover:bg-yellow-500 transition-all transform hover:-translate-y-1 shadow-[4px_4px_0px_rgba(255,255,255,0.2)]"
            >
              Solicitar Presupuesto
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-yellow-400 p-2 focus:outline-none"
            >
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden absolute w-full bg-black border-b border-yellow-400/20 transition-all duration-300 overflow-hidden ${isMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="px-4 pt-2 pb-6 space-y-1 flex flex-col items-center text-center">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="block w-full text-gray-300 hover:text-yellow-400 py-4 text-lg font-bold uppercase tracking-widest border-b border-gray-800"
              onClick={() => setIsMenuOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <a
            href="#presupuesto"
            className="mt-6 w-full bg-yellow-400 text-black py-4 font-black uppercase tracking-tighter"
            onClick={() => setIsMenuOpen(false)}
          >
            Solicitar Presupuesto
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
