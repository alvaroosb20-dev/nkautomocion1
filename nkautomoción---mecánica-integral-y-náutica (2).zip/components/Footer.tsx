
import React from 'react';
import { Instagram, Facebook, Twitter, ChevronUp } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-black py-16 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-12 mb-16">
          {/* Logo & Info */}
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-4">
              <div className="bg-yellow-400 p-1 rounded-sm rotate-3 shadow-[2px_2px_0px_#000]">
                <span className="text-black font-black text-xl italic leading-none">NK</span>
              </div>
              <span className="text-white font-heading font-black text-xl tracking-tighter uppercase">AUTOMOCIÓN</span>
            </div>
            <p className="text-gray-500 max-w-xs text-sm">
              Mecánica integral de alta performance. Especialistas en automotores, náutica y gestión de flotas empresariales.
            </p>
          </div>

          {/* Social Links */}
          <div className="flex gap-4">
             <a href="#" className="w-12 h-12 flex items-center justify-center border border-white/10 text-white hover:bg-yellow-400 hover:text-black transition-all">
                <Instagram size={20} />
             </a>
             <a href="#" className="w-12 h-12 flex items-center justify-center border border-white/10 text-white hover:bg-yellow-400 hover:text-black transition-all">
                <Facebook size={20} />
             </a>
             <a href="#" className="w-12 h-12 flex items-center justify-center border border-white/10 text-white hover:bg-yellow-400 hover:text-black transition-all">
                <Twitter size={20} />
             </a>
          </div>

          {/* Scroll to Top */}
          <button 
            onClick={scrollToTop}
            className="flex flex-col items-center gap-2 group"
          >
             <div className="bg-[#111] p-3 rounded-full border border-white/5 group-hover:border-yellow-400 transition-colors">
                <ChevronUp className="text-yellow-400" />
             </div>
             <span className="text-[10px] font-black uppercase tracking-widest text-gray-500 group-hover:text-yellow-400">Subir</span>
          </button>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-600 text-xs font-medium uppercase tracking-widest">
            © {new Date().getFullYear()} NKAUTOMOCIÓN. Todos los derechos reservados.
          </p>
          <div className="flex gap-6 text-[10px] font-black text-gray-600 uppercase tracking-widest">
            <a href="#" className="hover:text-yellow-400">Términos & Condiciones</a>
            <a href="#" className="hover:text-yellow-400">Privacidad</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
