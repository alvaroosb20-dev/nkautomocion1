
import React from 'react';

const AboutUs: React.FC = () => {
  return (
    <section id="nosotros" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="w-full lg:w-1/2 grid grid-cols-2 gap-4">
             <img src="https://picsum.photos/id/1055/500/600" alt="Workshop 1" className="w-full h-full object-cover grayscale" />
             <div className="space-y-4">
                <img src="https://picsum.photos/id/1018/500/300" alt="Workshop 2" className="w-full h-48 object-cover grayscale brightness-50" />
                <div className="bg-yellow-400 p-8 h-48 flex flex-col justify-end">
                   <span className="block text-4xl font-black text-black">15+</span>
                   <span className="text-xs font-bold uppercase tracking-widest text-black">Años de Trayectoria</span>
                </div>
             </div>
          </div>

          <div className="w-full lg:w-1/2">
            <h2 className="text-yellow-400 font-bold uppercase tracking-[0.2em] mb-4 text-sm">Nuestra Historia</h2>
            <h3 className="font-heading text-4xl md:text-5xl font-black text-white mb-8 leading-tight">
              PASIÓN POR LA <br /> <span className="text-yellow-400 italic">INGENIERÍA</span>
            </h3>
            <div className="space-y-6 text-gray-400 text-lg leading-relaxed">
              <p>
                NKAUTOMOCIÓN nació de una visión clara: elevar los estándares de servicio mecánico en la región. Lo que comenzó como un pequeño taller especializado, se ha convertido en un centro integral de tecnología automotriz y náutica.
              </p>
              <p>
                Nuestro enfoque combina la experiencia de mecánicos de la "vieja escuela" con la precisión que solo las herramientas de diagnóstico digital modernas pueden ofrecer. No solo reparamos vehículos; garantizamos tranquilidad para quienes dependen de sus motores día a día.
              </p>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                <li className="flex items-center gap-3 text-white font-bold italic">
                  <div className="w-2 h-2 bg-yellow-400"></div> Transparencia Total
                </li>
                <li className="flex items-center gap-3 text-white font-bold italic">
                  <div className="w-2 h-2 bg-yellow-400"></div> Repuestos Originales
                </li>
                <li className="flex items-center gap-3 text-white font-bold italic">
                  <div className="w-2 h-2 bg-yellow-400"></div> Garantía Escrita
                </li>
                <li className="flex items-center gap-3 text-white font-bold italic">
                  <div className="w-2 h-2 bg-yellow-400"></div> Equipo Certificado
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
