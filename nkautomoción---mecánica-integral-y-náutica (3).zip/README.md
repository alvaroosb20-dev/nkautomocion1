
# NKAUTOMOCIÓN - Mecánica Integral y Náutica

Sitio web profesional, moderno y funcional para **NKAUTOMOCIÓN**, especialistas en mecánica automotriz, servicios para flotas y mecánica náutica en Santa Cruz de Tenerife.

## 🛠️ Tecnologías utilizadas

- **React 19**: Biblioteca para la interfaz de usuario.
- **Tailwind CSS**: Framework de CSS para un diseño moderno y responsive.
- **Lucide React**: Set de iconos elegantes y minimalistas.
- **TypeScript**: Para un desarrollo robusto y tipado.
- **Google Gemini API**: Integrado para futuras capacidades de IA.

## 📍 Información de Contacto

- **Dirección**: Calle Laura Gröte de la puerta 14, 38110, Santa Cruz de Tenerife.
- **Teléfono**: 922 29 36 49
- **Email**: NKautomocion@gmail.com
- **Horario**: Lunes a Viernes (08:00 - 16:00).

## 🚀 Cómo ejecutar el proyecto

Este proyecto utiliza módulos ES nativos (ESM) y no requiere de un proceso de compilación complejo para desarrollo local inicial.

1. Clona el repositorio.
2. Abre el archivo `index.html` directamente en un navegador o, preferiblemente, usa un servidor local:
   ```bash
   # Si tienes Node.js instalado
   npx serve .
   ```

## ✒️ Diseño

El diseño sigue una estética industrial con una paleta de colores **Negro (#000000)** y **Amarillo (#FACC15)**, evocando potencia, precisión y herramientas profesionales.

---
Desarrollado para NKAUTOMOCIÓN.
