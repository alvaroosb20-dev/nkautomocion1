
import React from 'react';
import { 
  Wrench, 
  Cpu, 
  ShieldCheck, 
  Anchor, 
  Truck, 
  Tool, 
  Zap, 
  Clock, 
  CreditCard,
  Settings
} from 'lucide-react';
import { Service, Benefit } from './types';

export const COLORS = {
  primary: '#FACC15', // Tailwind yellow-400
  secondary: '#000000',
  accent: '#1F2937' // Tailwind gray-800
};

export const SERVICES: Service[] = [
  {
    id: 'general',
    title: 'Mecánica General',
    description: 'Reparación integral de motores, frenos, suspensión y transmisión para todo tipo de vehículos particulares.',
    icon: <Wrench className="w-8 h-8" />
  },
  {
    id: 'diag',
    title: 'Diagnóstico Computarizado',
    description: 'Equipamiento de última generación para identificar fallas electrónicas con precisión absoluta.',
    icon: <Cpu className="w-8 h-8" />
  },
  {
    id: 'prev',
    title: 'Mantenimiento Preventivo',
    description: 'Cambios de aceite, filtros y chequeos generales para evitar averías costosas y prolongar la vida de tu motor.',
    icon: <ShieldCheck className="w-8 h-8" />
  },
  {
    id: 'heavy',
    title: 'Reparaciones Mayores',
    description: 'Ajuste completo de motores, cajas automáticas y sistemas de inyección complejos.',
    icon: <Settings className="w-8 h-8" />
  },
  {
    id: 'marine',
    title: 'Mecánica Náutica',
    description: 'Especialistas en motores fuera de borda e internos. Puesta a punto y service oficial para embarcaciones.',
    icon: <Anchor className="w-8 h-8" />
  },
  {
    id: 'fleet',
    title: 'Servicio a Flotas',
    description: 'Mantenimiento integral para PYMES y empresas con atención prioritaria y planes a medida.',
    icon: <Truck className="w-8 h-8" />
  }
];

export const FLEET_BENEFITS: Benefit[] = [
  {
    title: 'Atención Prioritaria',
    description: 'Tus vehículos de trabajo no pueden estar parados. Priorizamos tus reparaciones.'
  },
  {
    title: 'Mantenimiento Programado',
    description: 'Agenda preventiva para evitar interrupciones inesperadas en tu logística.'
  },
  {
    title: 'Facturación Corporativa',
    description: 'Procesos administrativos ágiles y facturación adaptada a las necesidades de tu empresa.'
  }
];
