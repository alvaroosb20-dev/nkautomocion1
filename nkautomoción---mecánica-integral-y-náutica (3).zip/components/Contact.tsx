
import React from 'react';
import { Mail, Phone, MapPin, MessageSquare, ArrowRight, Clock } from 'lucide-react';

const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Mensaje enviado correctamente. Nos pondremos en contacto a la brevedad.');
  };

  return (
    <section id="contacto" className="py-24 bg-[#0a0a0a] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Info Side */}
          <div>
            <h2 className="font-heading text-5xl font-black text-white mb-8 uppercase">ESTAMOS <span className="text-yellow-400">LISTOS</span> <br /> PARA AYUDARTE</h2>
            <p className="text-gray-400 text-lg mb-12">
              Envianos tus consultas o solicitá un turno directamente. Nuestro equipo técnico responderá en menos de 24 horas hábiles.
            </p>

            <div className="space-y-6">
              <div className="flex gap-6 group">
                <div className="bg-yellow-400/10 p-4 border border-yellow-400/20 group-hover:bg-yellow-400 transition-colors duration-300 h-fit">
                  <Phone className="text-yellow-400 group-hover:text-black" />
                </div>
                <div>
                  <h4 className="text-white font-bold uppercase text-sm tracking-widest mb-1">Llamanos</h4>
                  <p className="text-gray-400 text-xl font-bold">922 29 36 49</p>
                </div>
              </div>

              <div className="flex gap-6 group">
                <div className="bg-yellow-400/10 p-4 border border-yellow-400/20 group-hover:bg-yellow-400 transition-colors duration-300 h-fit">
                  <Mail className="text-yellow-400 group-hover:text-black" />
                </div>
                <div>
                  <h4 className="text-white font-bold uppercase text-sm tracking-widest mb-1">Escribinos</h4>
                  <p className="text-gray-400 text-xl font-bold">NKautomocion@gmail.com</p>
                </div>
              </div>

              <div className="flex gap-6 group">
                <div className="bg-yellow-400/10 p-4 border border-yellow-400/20 group-hover:bg-yellow-400 transition-colors duration-300 h-fit">
                  <MapPin className="text-yellow-400 group-hover:text-black" />
                </div>
                <div>
                  <h4 className="text-white font-bold uppercase text-sm tracking-widest mb-1">Ubicación</h4>
                  <p className="text-gray-400 text-lg font-bold">Calle Laura Gröte de la puerta 14, 38110, Santa Cruz de Tenerife</p>
                </div>
              </div>

              <div className="flex gap-6 group">
                <div className="bg-yellow-400/10 p-4 border border-yellow-400/20 group-hover:bg-yellow-400 transition-colors duration-300 h-fit">
                  <Clock className="text-yellow-400 group-hover:text-black" />
                </div>
                <div>
                  <h4 className="text-white font-bold uppercase text-sm tracking-widest mb-1">Horarios</h4>
                  <p className="text-gray-400 text-md font-bold uppercase">Lunes a Viernes: 08:00 - 16:00</p>
                  <p className="text-gray-600 text-sm font-bold uppercase">Sábados y Domingos: Cerrado</p>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="mt-12 h-64 bg-gray-900 border border-white/5 grayscale relative overflow-hidden">
               <div className="absolute inset-0 flex items-center justify-center opacity-20">
                  <MapPin size={80} className="text-yellow-400 animate-bounce" />
               </div>
               <div className="absolute inset-0 flex items-end justify-center pb-6">
                  <span className="bg-yellow-400 text-black px-4 py-1 text-xs font-bold uppercase italic">Click para abrir en Google Maps</span>
               </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-black p-8 sm:p-12 border border-yellow-400/10 relative">
            <div className="absolute -top-1 -right-1 w-24 h-24 border-t-2 border-r-2 border-yellow-400"></div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-500 mb-2">Nombre Completo</label>
                  <input 
                    type="text" 
                    required
                    className="w-full bg-[#111] border border-white/10 p-4 text-white focus:outline-none focus:border-yellow-400 transition-colors"
                    placeholder="Tu nombre"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-500 mb-2">Email</label>
                  <input 
                    type="email" 
                    required
                    className="w-full bg-[#111] border border-white/10 p-4 text-white focus:outline-none focus:border-yellow-400 transition-colors"
                    placeholder="email@ejemplo.com"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-widest text-gray-500 mb-2">Teléfono / WhatsApp</label>
                <input 
                  type="tel" 
                  className="w-full bg-[#111] border border-white/10 p-4 text-white focus:outline-none focus:border-yellow-400 transition-colors"
                  placeholder="Tu teléfono"
                />
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-widest text-gray-500 mb-2">Servicio de Interés</label>
                <select className="w-full bg-[#111] border border-white/10 p-4 text-white focus:outline-none focus:border-yellow-400 transition-colors">
                  <option>Mecánica Particular</option>
                  <option>Flotas / PYMES</option>
                  <option>Mecánica Náutica</option>
                  <option>Diagnóstico Computarizado</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-widest text-gray-500 mb-2">Mensaje</label>
                <textarea 
                  rows={4}
                  className="w-full bg-[#111] border border-white/10 p-4 text-white focus:outline-none focus:border-yellow-400 transition-colors"
                  placeholder="¿En qué podemos ayudarte?"
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="w-full bg-yellow-400 text-black py-5 font-black uppercase tracking-tighter flex items-center justify-center gap-3 hover:bg-white transition-all duration-300"
              >
                Enviar Mensaje
                <ArrowRight size={20} />
              </button>
            </form>

            <a 
              href="https://wa.me/34922293649" 
              className="mt-8 flex items-center justify-center gap-3 text-green-500 font-bold hover:text-green-400 transition-colors uppercase text-sm tracking-widest"
            >
              <MessageSquare size={20} />
              Hablar por WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
