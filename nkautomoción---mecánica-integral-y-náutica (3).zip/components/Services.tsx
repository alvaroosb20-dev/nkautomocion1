
import React from 'react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="servicios" className="py-24 bg-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="text-yellow-400 font-bold uppercase tracking-[0.2em] mb-4 text-sm">Lo que hacemos</h2>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <h3 className="font-heading text-4xl md:text-5xl font-black text-white">SERVICIOS DE ALTA <br /> PERFORMANCE</h3>
            <p className="max-w-md text-gray-500 text-lg">
              Utilizamos tecnología de vanguardia y mano de obra calificada para garantizar que cada vehículo rinda al 100%.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service) => (
            <div 
              key={service.id} 
              className="group relative bg-gray-900 border border-white/5 p-8 hover:border-yellow-400/50 transition-all duration-500 hover:-translate-y-2"
            >
              <div className="absolute top-0 left-0 w-1 h-0 bg-yellow-400 group-hover:h-full transition-all duration-500"></div>
              
              <div className="bg-yellow-400/10 w-16 h-16 flex items-center justify-center mb-8 rounded-none border border-yellow-400/20 group-hover:bg-yellow-400 group-hover:text-black transition-colors duration-500">
                {service.icon}
              </div>

              <h4 className="font-heading text-xl font-bold text-white mb-4 group-hover:text-yellow-400 transition-colors">
                {service.title}
              </h4>
              
              <p className="text-gray-400 leading-relaxed mb-6">
                {service.description}
              </p>

              <div className="flex items-center gap-2 text-yellow-400 font-bold text-xs uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity translate-x-[-10px] group-hover:translate-x-0 duration-500">
                <span>Ver detalles</span>
                <span className="h-[2px] w-6 bg-yellow-400"></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
