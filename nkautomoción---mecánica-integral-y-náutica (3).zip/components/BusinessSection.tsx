
import React from 'react';
import { FLEET_BENEFITS } from '../constants';
import { CheckCircle2, Factory } from 'lucide-react';

const BusinessSection: React.FC = () => {
  return (
    <section id="empresas" className="py-24 bg-[#111] relative overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute top-0 right-0 p-20 opacity-5">
        <Factory size={400} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="bg-yellow-400 text-black px-3 py-1 text-xs font-black uppercase tracking-widest mb-6 inline-block">
              Sector PYMES & Flotas
            </span>
            <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl font-black text-white mb-8 leading-tight uppercase">
              TU NEGOCIO NO <span className="text-yellow-400">PUEDE PARAR</span>
            </h2>
            <p className="text-gray-400 text-lg mb-10 leading-relaxed">
              Sabemos que cada minuto que tu vehículo de trabajo está fuera de servicio representa una pérdida. Ofrecemos soluciones logísticas integrales para flotas de cualquier tamaño.
            </p>

            <div className="space-y-6">
              {FLEET_BENEFITS.map((benefit, idx) => (
                <div key={idx} className="flex gap-4 p-6 bg-black/50 border border-white/5 hover:border-yellow-400/20 transition-colors">
                  <div className="flex-shrink-0">
                    <CheckCircle2 className="text-yellow-400 w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-lg mb-1">{benefit.title}</h4>
                    <p className="text-gray-500 text-sm leading-relaxed">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <button className="mt-12 bg-white text-black px-10 py-5 font-black uppercase tracking-tighter hover:bg-yellow-400 transition-all duration-300">
              Solicitar Plan Corporativo
            </button>
          </div>

          <div className="relative group">
            <div className="absolute -inset-4 border border-yellow-400/20 group-hover:border-yellow-400/40 transition-all duration-500"></div>
            <img 
              src="https://picsum.photos/id/1070/800/1000" 
              alt="Business fleet" 
              className="w-full h-auto object-cover grayscale brightness-75 group-hover:grayscale-0 transition-all duration-700"
            />
            {/* Stats Overlay */}
            <div className="absolute bottom-8 left-8 right-8 bg-black/90 p-8 border-l-8 border-yellow-400">
               <div className="grid grid-cols-2 gap-8 text-center">
                  <div>
                    <span className="block text-4xl font-black text-yellow-400">100+</span>
                    <span className="text-xs text-gray-400 uppercase font-bold tracking-widest">Empresas Aliadas</span>
                  </div>
                  <div>
                    <span className="block text-4xl font-black text-yellow-400">24h</span>
                    <span className="text-xs text-gray-400 uppercase font-bold tracking-widest">Respuesta Promedio</span>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessSection;
